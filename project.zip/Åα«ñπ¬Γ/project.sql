-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Май 31 2024 г., 12:34
-- Версия сервера: 10.4.28-MariaDB
-- Версия PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `project`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

CREATE TABLE `accounts` (
  `aid` int(11) NOT NULL,
  `afname` varchar(100) NOT NULL,
  `alname` varchar(100) NOT NULL,
  `phone` char(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cnic` char(13) NOT NULL,
  `dob` date NOT NULL,
  `username` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`aid`, `afname`, `alname`, `phone`, `email`, `cnic`, `dob`, `username`, `gender`, `password`) VALUES
(5, 'Герман', 'Барантекс', '03150100830', 'kitaynash40@gmail.com', '3530231218003', '2004-05-03', 'admin1', 'M', 'admin123'),
(21, 'Leonid', 'Darkhaev', '12345678901', 'bury@gmail.com', '8888646464', '2004-05-03', 'buryprom11', 'M', 'buryprom1');

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `aid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `cqty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `order-details`
--

CREATE TABLE `order-details` (
  `oid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `order-details`
--

INSERT INTO `order-details` (`oid`, `pid`, `qty`) VALUES
(26, 39, 1),
(27, 39, 1),
(28, 36, 1),
(28, 40, 1),
(29, 27, 1),
(30, 43, 1),
(31, 34, 1),
(32, 30, 1),
(32, 39, 1),
(33, 42, 1),
(34, 36, 1),
(34, 38, 2),
(34, 43, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL,
  `dateod` date NOT NULL,
  `datedel` date DEFAULT NULL,
  `aid` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `account` char(16) DEFAULT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`oid`, `dateod`, `datedel`, `aid`, `address`, `city`, `country`, `account`, `total`) VALUES
(26, '2024-05-30', '2024-05-30', 5, 'Пушкина', 'Москва', 'Россия', NULL, 85),
(27, '2024-05-30', '2024-05-30', 5, 'Пушкина', 'Бур', 'Бур', NULL, 85),
(28, '2024-05-31', '2024-05-31', 21, 'Пушкина', 'Москва', '223222', NULL, 380),
(29, '2024-05-31', '2024-05-31', 21, 'Komarova 16', 'Ulan-UDe', 'RF', NULL, 480),
(30, '2024-05-31', '2024-05-31', 21, 'Карла', 'Макрса', 'Улан', NULL, 400),
(31, '2024-05-31', '2024-05-31', 21, '123', '123', '123', NULL, 160),
(32, '2024-05-31', '2024-05-31', 21, '21312323', '123312', 'hfhf', NULL, 85),
(33, '2024-05-31', '2024-05-31', 21, '435', '345', '435345', NULL, 390),
(34, '2024-05-31', '2024-05-31', 21, 'Пушкина', 'Москва', '12', NULL, 880);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `price` int(11) NOT NULL,
  `qtyavail` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `brand` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`pid`, `pname`, `category`, `description`, `price`, `qtyavail`, `img`, `brand`) VALUES
(27, 'Том Ям', 'Супы', '— Кисло-острый суп с креветками, курицей, рыбой или другими морепродуктами. Национальное блюдо Лаоса и Таиланда.', 480, 9, 'x14.jpeg', 'Тайская кухня'),
(30, 'Шулэн', 'Супы', ' Одно из традиционных блюд бурятской кухни — суп-лапша шулэн. Учитывая кочевой характер бурятского народа, популярность супа объяснялась тем, что он надолго обеспечивал сытость.', 165, 14, 'x3.jpeg', 'Бурятский суп'),
(31, 'Салат с куриной грудкой', 'Салаты', ' — Прекрасный выбор для вкусного салата на праздничный стол', 380, 19, 'x5.jpeg', 'Салат'),
(32, 'Хорхаг', 'Баранина', '— Мясо, тушёное в закрытом металлическом котле на раскалённых камнях; блюдо монгольской кухни.', 3500, 12, 'x15.jpeg', 'Блюда на компанию'),
(33, 'Мясное ассорти', 'Ассорти', '— Холодная закуска, которая не только раздразнит аппетит, но и послужит настоящим украшением стола. Чаще всего его можно увидеть на фуршетах, шведском столе или в ресторане. Мясное ассорти эффектно до', 3500, 5, 'x6.jpeg', 'Ассорти'),
(34, 'Теплый салат с баклажаном', 'Салаты', '— Это салат с хрустящими баклажанами и томатами. Сладкий соус чили и свежая кинза отлично дополняют вкус.', 160, 1, 'x9.jpeg', 'Салаты'),
(35, 'Ногоон', 'Салаты', '- Цукине, огурцы, яблоко, лист салата, овощная заправка', 330, 3, '71GJY5+c14L._SY450_.jpg', 'Салаты'),
(36, 'Цуйван', 'Говядина', '— Традиционное монгольское блюдо. Вид лапши, популярный у многих народов Азии. Для цуйвана сначала готовят на пару тонкие лепёшки из теста, свёрнутые валиком. ', 350, 9, 'lol.jpeg', 'Говядина'),
(37, 'Бантан', 'Супы', '— наваристый бульон из баранины с легкой мучной \"затирухой\" и с редким добавлением кореньев и специй для вкуса.', 280, 3, 'rog.jpeg', 'Супы'),
(38, 'Позы', 'Пельмени', '— Это род паровых пельменей с отверстием наверху. Происхождение они ведут от китайских паровых пирожков баоцзы — но с течением времени развились в нечто совершенно другое.', 65, 3, 'no.jpeg', 'Пельмени'),
(39, 'Хушуур', 'Пельмени', '– Жаренные в масле «кармашки» из теста с мясной начинкой. В классическом варианте готовятся из пресного несоленого теста, замешанного на воде с мукой. ', 85, 12, 'i.jpeg', 'Пельмени'),
(40, 'Лосось на жаровне под соусом терияки', 'Рыба', 'Лосось, маринованный в соусе терияки, приобретает интенсивный сладковато-соленый вкус с легкой ноткой имбиря и аромата чеснока.', 380, 3, 'red.jpeg', 'Рыба'),
(41, 'Хуйцаа', 'Супы', '- Монгольский, наваристый и густой суп с овощами и мясом. ', 270, 8, 'r.jpeg', 'Супы'),
(42, 'Уха по-азиатски', 'Супы', '— Азиатское первое блюдо, представляющее собой прозрачный отвар из свежей рыбы одного или нескольких видов, а также трёх овощей: картофеля, моркови и лука с различными приправами. ', 390, 7, 'g.jpeg', 'Супы'),
(43, 'Хугабша', 'Ассорти', '– Бурятское блюдо из печени, обернутой сальником и зажаренной на углях до хрустящей корочки. Другое название – «печень в рубашке».', 400, 1, 'Rtx.jpeg', 'Ассорти');

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `oid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `rtext` varchar(1000) DEFAULT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`oid`, `pid`, `rtext`, `rating`) VALUES
(28, 36, ' 123', 5),
(28, 40, ' 123', 3),
(29, 27, ' 333333', 5),
(30, 43, ' 123', 1),
(31, 34, ' оло1', 2),
(32, 30, ' 1234567', 5),
(32, 39, ' 1234521', 1),
(33, 42, ' 324', 5),
(34, 36, ' вкусно', 4),
(34, 38, ' вкуснаа', 5),
(34, 43, ' ммм', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `wishlist`
--

CREATE TABLE `wishlist` (
  `aid` int(11) NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`aid`),
  ADD UNIQUE KEY `cnic` (`cnic`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`aid`,`pid`),
  ADD KEY `cartfk2` (`pid`);

--
-- Индексы таблицы `order-details`
--
ALTER TABLE `order-details`
  ADD PRIMARY KEY (`oid`,`pid`),
  ADD KEY `orderdtfk2` (`pid`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `ordersfk` (`aid`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`oid`,`pid`),
  ADD KEY `reviewsfk2` (`pid`);

--
-- Индексы таблицы `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`aid`,`pid`),
  ADD KEY `wishlistfk2` (`pid`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `accounts`
--
ALTER TABLE `accounts`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cartfk1` FOREIGN KEY (`aid`) REFERENCES `accounts` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cartfk2` FOREIGN KEY (`pid`) REFERENCES `products` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `order-details`
--
ALTER TABLE `order-details`
  ADD CONSTRAINT `orderdtfk1` FOREIGN KEY (`oid`) REFERENCES `orders` (`oid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderdtfk2` FOREIGN KEY (`pid`) REFERENCES `products` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `ordersfk` FOREIGN KEY (`aid`) REFERENCES `accounts` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviewsfk1` FOREIGN KEY (`oid`) REFERENCES `orders` (`oid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reviewsfk2` FOREIGN KEY (`pid`) REFERENCES `products` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlistfk1` FOREIGN KEY (`aid`) REFERENCES `accounts` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `wishlistfk2` FOREIGN KEY (`pid`) REFERENCES `products` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
