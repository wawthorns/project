<?php
session_start();

$log_file = 'attendance.log';

// Создание файла лога, если он не существует
if (!file_exists($log_file)) {
    file_put_contents($log_file, "Дата,Время,Пользователь\n");
}

// Определение пользователя
if (empty($_SESSION['aid'])) {
    $_SESSION['aid'] = -1;
    $user = "Гость";
} else {
    $user = "Пользователь" . $_SESSION['aid'];
}

// Запись данных в файл лога
$log_entry = date('Y-m-d') . "," . date('H:i:s') . "," . $user . "\n";
file_put_contents($log_file, $log_entry, FILE_APPEND);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>БАЙКАЛ-АЛЬЯНС</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <section id="header">
        <a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>
        <div>
            <ul id="navbar">
                <li><a class="active" href="index.php">Главная</a></li>
                <li><a href="shop.php">Ресторан</a></li>
                <li><a href="about.php">О нас</a></li>
                <li><a href="contact.php">Адрес</a></li>
                <?php
                if ($_SESSION['aid'] < 0) {
                    echo "<li><a href='login.php'>Войти</a></li>
                          <li><a href='signup.php'>Регистрация</a></li>";
                } else {
                    echo "<li><a href='profile.php'>Профиль</a></li>";
                }
                ?>
                <li><a href="admin.php">Админ</a></li>
                <li id="lg-bag">
                    <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
                </li>
                <a href="#" id="close"><i class="far fa-times'></i></a>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>
    <section id="hero">
        <h4>Этнокомплекс</h4>
        <h2>СЕТЬ БАЙКАЛ</h2>
        <h1>АЛТАН-БУРГЭД</h1>
        <p>Улан-Удэ</p>
    </section>
</body>
</html>
