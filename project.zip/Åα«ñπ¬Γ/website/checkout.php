<?php
session_start();

if (isset($_POST['sub'])) {
    include("include/connect.php");

    $aid = $_SESSION['aid'];
    $add = $_POST['houseadd'];
    $city = $_POST['city'];
    $country = $_POST['country'];
    $acc = $_POST['acc'];
    $query = "";
    $tott = 0; // Инициализация переменной

    if (empty($acc)) {
        $query = "insert into `orders` (dateod, datedel, aid, address, city, country, account, total) values(CURDATE(), NULL, '$aid', '$add', '$city', '$country', NULL, 0)";
    } else {
        if (preg_match('/\D/', $acc) || strlen($acc) != 16) {
            echo "<script> alert('invalid account number'); setTimeout(function(){ window.location.href = 'checkout.php'; }, 100); </script>";
            exit();
        }

        $query = "insert into `orders` (dateod, datedel, aid, address, city, country, account, total) values(CURDATE(), NULL, '$aid', '$add', '$city', '$country', '$acc', 0)";
    }
    $result = mysqli_query($con, $query);

    if (!$result) {
        die("Ошибка выполнения запроса: " . mysqli_error($con));
    }

    $oid = mysqli_insert_id($con);

    $query = "SELECT * FROM cart JOIN products ON cart.pid = products.pid WHERE aid = $aid";
    $result = mysqli_query($con, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $pid = $row['pid'];
        $pname = $row['pname'];
        $desc = $row['description'];
        $qty = $row['qtyavail'];
        $price = $row['price'];
        $cat = $row['category'];
        $img = $row['img'];
        $brand = $row['brand'];
        $cqty = $row['cqty'];
        $tott += $price * $cqty;

        $query = "insert into `order-details` (oid, pid, qty) values ($oid, $pid, $cqty)";
        mysqli_query($con, $query);

        $query = "update products set qtyavail = qtyavail - $cqty where pid = $pid";
        mysqli_query($con, $query);
    }

    $query = "delete from cart where aid = $aid";
    mysqli_query($con, $query);

    $query = "update orders set total = $tott where oid = $oid";
    mysqli_query($con, $query);

    header("Location: profile.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>БАЙКАЛ-АЛЬЯНС</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="style.css" />
    <style>
        #account-field {
            display: block;
        }
        .hidden {
            display: none;
        }
        .input11 {
            display: block;
            width: 80%;
            margin: 40px auto;
            padding: 10px 5px;
            border: none;
            border-bottom: 0.01rem dimgray solid;
            outline: none;
        }
        .table12 {
            margin: 0;
            padding: 0;
            width: 100%;
            overflow: auto;
        }
        .table12 tr {
            width: 100%;
            overflow: auto;
        }
    </style>
</head>
<body>
    <section id="header">
        <a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>
        <div>
            <ul id="navbar">
                <li><a href="index.php">Главная</a></li>
                <li><a href="shop.php">Ресторан</a></li>
                <li><a href="about.php">О нас</a></li>
                <li><a href="contact.php">Адрес</a></li>
                <?php
                if ($_SESSION['aid'] < 0) {
                    echo "   <li><a href='login.php'>Войти</a></li>
                            <li><a href='signup.php'>Регистрация</a></li>";
                } else {
                    echo "   <li><a href='profile.php'>Профиль</a></li>";
                }
                ?>
                <li><a href="admin.php">Админ</a></li>
                <li id="lg-bag">
                    <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
                </li>
                <a href="#" id="close"><i class="far fa-times"></i></a>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>
    <div class="container">
        <div class="titlecheck">
            <h2>Форма заказа продукта</h2>
        </div>
        <div class="d-flex">
            <form method="post" id="form1">
                <h3 style="color: darkred; margin: auto"></h3>
                <input class="input11" type="text" name="houseadd" placeholder="Улица" required>
                <input class="input11" type="text" name="city" placeholder="Город" required>
                <input class="input11" type="text" name="country" placeholder="Дом" required>
                <div>
                    <input class="input2" type="radio" id="ac1" name="dbt" value="cod" onchange="showInputBox()"> Наложенный
платеж при доставке
                </div>

                <button name="sub" type="submit" class="btn112">Разместить заказ</button>
            </form>
            <div class="Yorder">
                <table class="table12">
                    <tr class='tr1'>
                        <th class='th1' colspan='2'>Ваш заказ</th>
                    </tr>
                    <?php
                    include("include/connect.php");
                    $aid = $_SESSION['aid'];
                    $query = "SELECT * FROM cart JOIN products ON cart.pid = products.pid WHERE aid = $aid";
                    $result = mysqli_query($con, $query);
                    $tot = 0; // Инициализация переменной
                    while ($row = mysqli_fetch_assoc($result)) {
                        $pid = $row['pid'];
                        $pname = $row['pname'];
                        $desc = $row['description'];
                        $qty = $row['qtyavail'];
                        $price = $row['price'];
                        $cat = $row['category'];
                        $img = $row['img'];
                        $brand = $row['brand'];
                        $cqty = $row['cqty'];
                        $a = $price * $cqty;
                        $tot += $a;
                        echo "
                        <tr class='tr1'>
                            <td class='td1'>$pname x $cqty</td>
                            <td class='td1'>$a</td>
                        </tr>";
                    }
                    echo "
                    <tr class='tr1'>
                        <td class='td1'>Промежуточный итог</td>
                        <td class='td1'>$tot.00</td>
                    </tr>
                    <tr class='tr1'>
                        <td class='td1'>Доставка</td>
                        <td class='td1'>Бесплатная доставка</td>
                    </tr>";
                    ?>
                </table><br>
            </div><!-- Yorder -->
        </div>
    </div>
    <footer class="section-p1">
        <div class="col">
            <a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>
            <h4>Связаться с нами</h4>
            <p>
                <strong>Адрес: </strong> Серебряный переулок, 15а/2 город Улан-Удэ
            </p>
            <p>
                <strong>Номер телефона: </strong> +7(983)537-20-29
            </p>
            <p>
                <strong>Часы работы: </strong> 10:00-20:00
            </p>
        </div>
        <div class="col">
            <h4>Мой профиль</h4>
            <a href="cart.php">Просмотр корзины</a>
            <a href="wishlist.php">Мой список желаний</a>
        </div>
        <div class="col install">
            <p>Secured Payment Gateways</p>
            <img src="img/pay/pay.png" />
        </div>
        <div class="copyright">
            <p>2024. Baikal. HTML CSS JS </p>
        </div>
    </footer>
    <script src="script.js"></script>
</body>
</html>

<script>
    function showInputBox() {
        var select = document.querySelector('#ac1');
        var inputBox = document.getElementById("account-field");
        if (!select.checked) {
            inputBox.style.display = "block";
        } else {
            inputBox.style.display = "none";
        }
    }
</script>

<script>
window.addEventListener("unload", function() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "logout.php", false);
    xhr.send();
});
</script>
