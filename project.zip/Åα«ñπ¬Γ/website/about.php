<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>БАЙКАЛ-АЛЬЯНС</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

    <link rel="stylesheet" href="style.css" />

    <style>
    .paragraph {
        line-height: 1.5;
    }
    </style>


</head>

<body>
    <section id="header">
<a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Главная</a></li>
                <li><a href="shop.php">Ресторан</a></li>
                <li><a class="active" href="about.php">О нас</a></li>
                <li><a href="contact.php">Адрес</a></li>

                <?php

                if ($_SESSION['aid'] < 0) {
                    echo "   <li><a href='login.php'>Войти</a></li>
            <li><a href='signup.php'>Регистрация</a></li>
            ";
                } else {
                    echo "   <li><a href='profile.php'>Профиль</a></li>
          ";
                }
                ?>
                <li><a href="admin.php">Админ</a></li>
                <li id="lg-bag">
                    <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
                </li>
                <a href="#" id="close"><i class="far fa-times"></i></a>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>

    <section id="page-header" class="about-header">
        <h2>#БуузыПозыВкусно</h2>

        <p>Предоставление акции и купонов на позы!</p>
    </section>

    <section id="about-head" class="section-p1">
        <img src="img/about/x2.jpg" alt="" />
        <div>
            <h2>О нас?</h2>
            <p class="paragraph">
                Алтан Бургэд - этно-комплекс в Улан-Удэ, Россия. Мы предлагаем уникальный опыт знакомства с бурятской культурой и традициями. Наши услуги включают в себя экскурсии, мастер-классы, национальную кухню и многое другое. Свяжитесь с нами по телефону +7 (983) 537-20-29 или по адресу: Серебряный переулок, 15а.
				.: ООО «Байкал-Альянс» – полностью самостоятельная организация, не входящая в альянсы и холдинги ни с кем из предприятий отрасли деятельности.
				
				ресто-клуб «Че Гевара», караоке-холл «Гавана», этно-кафе «Звезда кочевника». 
            </p>
            <br /><br />
            <marquee bgcolor="#ccc" loop="-1" scrollamount="5">baikal food rest yummy! altan-burged pozi ulan-ude number one high cafe restoraunt</marquee>
        </div>
    </section>

    <section id="feature" class="section-p1">
        <div class="fe-box">
            <img src="img/features/f1.png" alt="" />
            <h6>Доставка</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f2.png" alt="" />
            <h6>Онлайн-заказы</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f3.png" alt="" />
            <h6>Сэкономить время и ваши средства</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f4.png" alt="" />
            <h6>Акции</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f5.png" alt="" />
            <h6>Хорошие отзывы</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f6.png" alt="" />
            <h6>24/7 Техподдержка</h6>
        </div>
    </section>


   <footer class="section-p1">
        <div class="col">
            <a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>
            <h4>Связаться с нами</h4>
            <p>
                <strong>Адрес: </strong> Серебряный переулок, 15а/2 город Улан-Удэ
            </p>
            <p>
                <strong>Номер телефона: </strong> +7(983)537-20-29
            </p>
            <p>
                <strong>Часы работы: </strong> 10:00-20:00
            </p>
        </div>

        <div class="col">
            <h4>Мой профиль</h4>
            <a href="cart.php">Просмотр корзины</a>
            <a href="wishlist.php">Мой список желаний</a>
        </div>
        <div class="col install">
            <p>Secured Payment Gateways</p>
            <img src="img/pay/pay.png" />
        </div>
        <div class="copyright">
            <p>2024. Baikal. HTML CSS JS </p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>

</html>

<script>
window.addEventListener("unload", function() {
  // Call a PHP script to log out the user
  var xhr = new XMLHttpRequest();
  xhr.open("GET", "logout.php", false);
  xhr.send();
});
</script>