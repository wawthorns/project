<?php
session_start();

if (empty($_SESSION['aid']))
    $_SESSION['aid'] = -1;
include 'log_visitor.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>БАЙКАЛ-АЛЬЯНС</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <section id="header">
        <a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>

        <div>
            <ul id="navbar">
                <li><a class="active" href="index.php">Главная</a></li>
                <li><a href="shop.php">Ресторан</a></li>
                <li><a href="about.php">О нас</a></li>
                <li><a href="contact.php">Адрес</a></li>

                <?php
                if ($_SESSION['aid'] < 0) {
                    echo "   <li><a href='login.php'>Войти</a></li>
            <li><a href='signup.php'>Регистрация</a></li>
            ";
                } else {
                    echo "   <li><a href='profile.php'>Профиль</a></li>
          ";
                }
                ?>
                <li><a href="admin.php">Админ</a></li>
                <li id="lg-bag">
                    <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
                </li>
                <a href="#" id="close"><i class="far fa-times"></i></a>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>

    <section id="hero">
        <h4>Этнокомплекс</h4>
        <h2>СЕТЬ БАЙКАЛ</h2>
        <h1>АЛТАН-БУРГЭД</h1>
        <p>Улан-Удэ</p>
    </section>

    <section id="feature" class="section-p1">
        <div class="fe-box">
            <img src="img/features/f1.png" alt="" />
            <h6>Доставка</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f2.png" alt="" />
            <h6>Онлайн-заказы</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f3.png" alt="" />
            <h6>Сэкономить время и ваши средства</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f4.png" alt="" />
            <h6>Акции</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f5.png" alt="" />
            <h6>Хорошие отзывы</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f6.png" alt="" />
            <h6>24/7 Техподдержка</h6>
        </div>
    </section>

    <section id="sm-banner" class="section-p1">
        <div class="banner-box">
            <h4>Скидки!</h4>
            <h2>Купите комбо и получите один аксессуар бесплатно</h2>
            <span>Лучшая классика продается на Алтан Бургэд</span>
            <a href="shop.php">
                <button class="white">Узнать больше</button>
            </a>
        </div>
        <div class="banner-box banner-box2">
            <h4>Фавориты на этой неделе</h4>
            <h2>Распродажа блюд</h2>
            <span>Лучшая национальная классика Бурятии</span>
            <a href="shop.php">
                <button class="white">Узнать больше</button>
            </a>
        </div>
    </section>

    <section id="banner3">
        <div class="banner-box">
            <h2>Бухлёры, супы</h2>
            <h3> 25% Акция</h3>
        </div>
        <div class="banner-box banner-box2">
            <h2>В горшочках</h2>
            <h3>30% Акция</h3>
        </div>
        <div class="banner-box banner-box3">
            <h2>Белый месяц</h3>
            <h3>50% Акция</h3>
        </div>
    </section>

    <footer class="section-p1">
        <div class="col">
            <a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>
            <h4>Связаться с нами</h4>
            <p>
                <strong>Адрес: </strong> Серебряный переулок, 15а/2 город Улан-Удэ
            </p>
            <p>
                <strong>Номер телефона: </strong> +7(983)537-20-29
            </p>
            <p>
                <strong>Часы работы: </strong> 10:00-20:00
            </p>
        </div>

        <div class="col">
            <h4>Мой профиль</h4>
            <a href="cart.php">Просмотр корзины</a>
            <a href="wishlist.php">Мой список желаний</a>
        </div>
        <div class="col install">
            <p>Secured Payment Gateways</p>
            <img src="img/pay/pay.png" />
        </div>
        <div class="copyright">
            <p>2024. Baikal. HTML CSS JS </p>
        </div>
    </footer>

    <button id="open-menu" class="menu-button">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-messenger" viewBox="0 0 16 16">
  <path d="M0 7.76C0 3.301 3.493 0 8 0s8 3.301 8 7.76-3.493 7.76-8 7.76c-.81 0-1.586-.107-2.316-.307a.64.64 0 0 0-.427.03l-1.588.702a.64.64 0 0 1-.898-.566l-.044-1.423a.64.64 0 0 0-.215-.456C.956 12.108 0 10.092 0 7.76m5.546-1.459-2.35 3.728c-.225.358.214.761.551.506l2.525-1.916a.48.48 0 0 1 .578-.002l1.869 1.402a1.2 1.2 0 0 0 1.735-.32l2.35-3.728c.226-.358-.214-.761-.551-.506L9.728 7.381a.48.48 0 0 1-.578.002L7.281 5.98a1.2 1.2 0 0 0-1.735.32z"/>
</svg>
    </button>

<div id="menu">
    <p>Привет, меня зовут Леонид. И я ваш ассистент Байкал-Альянс!</p>
    <button id="instagram">Instagram</button>
    <button id="feedback">Оставить отзыв</button>
    <button id="support">Позвонить в поддержку</button>
    <p id="support-number" style="display:none;">+79835372029</p>
    <button id="close-menu">Закрыть</button>
</div>

<div id="feedback-form" style="display: none; background-color: #f9f9f9; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 400px; margin: auto;">
    <h3 style="text-align: center; color: #333;">Оставить отзыв</h3>
    <form method="POST" action="index.php">
        <div style="margin-bottom: 15px;">
            <label for="name" style="display: block; color: #666; margin-bottom: 5px;">Имя:</label>
            <input type="text" id="name" name="name" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>
        <div style="margin-bottom: 15px;">
            <label for="phone" style="display: block; color: #666; margin-bottom: 5px;">Телефон:</label>
            <input type="text" id="phone" name="phone" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>
        <div style="margin-bottom: 15px;">
            <label for="review" style="display: block; color: #666; margin-bottom: 5px;">Отзыв:</label>
            <textarea id="review" name="review" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; height: 100px;"></textarea>
        </div>
        <div style="text-align: center;">
            <button type="submit" style="background-color: #4CAF50; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">Отправить</button>
            <button id="close-feedback-form" style="background-color: #f44336; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin-left: 10px;">Закрыть</button>
        </div>
    </form>
</div>

<script>
    window.addEventListener("beforeunload", function() {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "logout.php", false);
        xhr.send();
    });

    document.addEventListener("DOMContentLoaded", function() {
        var menu = document.getElementById("menu");
        var feedbackForm = document.getElementById("feedback-form");
        var openMenuButton = document.getElementById("open-menu");
        var closeMenuButton = document.getElementById("close-menu");
        var closeFeedbackFormButton = document.getElementById("close-feedback-form");
        var supportNumber = document.getElementById("support-number");

        openMenuButton.addEventListener("click", function() {
            menu.style.display = "block";
        });

        closeMenuButton.addEventListener("click", function() {
            menu.style.display = "none";
            supportNumber.style.display = "none";
        });

        closeFeedbackFormButton.addEventListener("click", function() {
            feedbackForm.style.display = "none";
        });

        document.getElementById("instagram").addEventListener("click", function() {
            window.open("https://www.instagram.com/altanburged03?igsh=NTc4MTIwNjQ2YQ==", "_blank");
        });

        document.getElementById("feedback").addEventListener("click", function() {
            feedbackForm.style.display = "block";
            menu.style.display = "none";
        });

        document.getElementById("support").addEventListener("click", function() {
            supportNumber.style.display = "block";
        });
    });
</script>

</body>
</html>

<style>
    #menu {
        display: none;
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #f1f1f1;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        width: 300px;
        z-index: 1000;
    }

    #menu button {
        margin-top: 10px;
        padding: 5px 10px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    #menu button:hover {
        background-color: #0056b3;
    }

    #open-menu {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 10px 20px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        z-index: 1000;
    }

    #feedback-form {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #f1f1f1;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        width: 300px;
        z-index: 1000;
    }

    #feedback-form form {
        display: flex;
        flex-direction: column;
    }

    #feedback-form label,
    #feedback-form input,
    #feedback-form textarea {
        margin-bottom: 10px;
    }

    #feedback-form button {
        margin-top: 10px;
        padding: 5px 10px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    #feedback-form button:hover {
        background-color: #0056b3;
    }
</style>
