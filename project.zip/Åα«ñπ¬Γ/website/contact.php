<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>БАЙКАЛ-АЛЬЯНС</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

    <link rel="stylesheet" href="style.css" />

</head>

<body>
    <section id="header">
<a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Главная</a></li>
                <li><a href="shop.php">Ресторан</a></li>
                <li><a href="about.php">О нас</a></li>
                <li><a class="active" href="contact.php">Адрес</a></li>

                <?php

                if ($_SESSION['aid'] < 0) {
                    echo "   <li><a href='login.php'>Войти</a></li>
            <li><a href='signup.php'>Регистрация</a></li>
            ";
                } else {
                    echo "   <li><a href='profile.php'>Профиль</a></li>
          ";
                }
                ?>
                <li><a href="admin.php">Админ</a></li>
                <li id="lg-bag">
                    <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
                </li>
                <a href="#" id="close"><i class="far fa-times"></i></a>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>

    <section id="page-header" class="about-header">
        <h2>#АлтанБургэдУланУдэ</h2>

        <p>Этнокомплекс в Бурятии</p>
    </section>

    <section id="contact-details" class="section-p1">
        <div class="details">
            <span>СВЯЗАТЬСЯ</span>
            <h2>Посетите одно из представительств нашего агентства или свяжитесь с нами сегодня</h2>
            <h3>Ресторан</h3>
            <div>
                <li>
                    <i class="fal fa-map"></i>
                    <p>Серебряный переулок, 15а/2</p>
                </li>
                <li>
                    <i class="fal fa-envelope"></i>
                    <p>altanburgeduu@mail.ru</p>
                </li>
                <li>
                    <i class="fal fa-phone-alt"></i>
                    <p>+7(983) 537 20-29</p>
                </li>
                <li>
                    <i class="fal fa-clock"></i>
                    <p>С понедельника по субботу: с 10 утра по 00:00 ночи</p>

                </li>
            </div>
        </div>
    <div class="map">
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2351.282387661601!2d107.59138741621498!3d51.834651579698664!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5da902abf25f1c21%3A0xd82c5f2c5ef4bb8f!2z0KHQtdC80LXQvdC40Lkg0JrQvtGA0L7QstGB0LrQuNC5LCAxN9GDLzIsINCi0LDQvNC40YHRgtGA0L7RgdGC0YDQvtC60LgsINCh0LjQutC-0YLQtdC70YzRgdC60LDRjyDQvtCx0YDRgNC40LkgNjcwMDQ1!5e0!3m2!1sru!2sru!4v1689953612930!5m2!1sru!2sru"
            width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    </section>

    <section id="form-details">
        <div class="people">
            <div>
                <img src="img/people/a.jpeg" alt="" />
                <p>
                    <span>Даржаев Саян Юрьевич</span> Гендиректор БАЙКАЛ-АЛЬЯНС<br />
                    Номер телефона: +7 (999) 200 33-33 <br />
                    Почта: sayandarjiev@bk.ru
                </p>
            </div>
            <div>
                <img src="img/people/a.jpeg" alt="" />
                <p>
                    <span>Дондуков Герман Вадимович</span> Основатель сайта <br />
                    Номер телефона: +7 (964) 408 77-61 <br />
                    Почта: german1dis@gmail.com
                </p>
            </div>
            <div>
                <img src="img/people/a.jpeg" alt="" />
                <p>
                    <span>Даркхаев Леонид Васильевич</span> Менеджер по продажам и техническая поддержка <br />
                    Номер телефона: +7 (983) 537 20-29 <br />
                    Почта: klen_y@bk.ru
                </p>
            </div>
        </div>
    </section>

   <footer class="section-p1">
        <div class="col">
            <a href="index.php"><img src="img/logo.png" class="logo" alt="" style="width: 290px; height: auto;" /></a>
            <h4>Связаться с нами</h4>
            <p>
                <strong>Адрес: </strong> Серебряный переулок, 15а/2 город Улан-Удэ
            </p>
            <p>
                <strong>Номер телефона: </strong> +7(983)537-20-29
            </p>
            <p>
                <strong>Часы работы: </strong> 10:00-20:00
            </p>
        </div>

        <div class="col">
            <h4>Мой профиль</h4>
            <a href="cart.php">Просмотр корзины</a>
            <a href="wishlist.php">Мой список желаний</a>
        </div>
        <div class="col install">
            <p>Secured Payment Gateways</p>
            <img src="img/pay/pay.png" />
        </div>
        <div class="copyright">
            <p>2024. Baikal. HTML CSS JS </p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>

</html>

<script>
window.addEventListener("unload", function() {
  // Call a PHP script to log out the user
  var xhr = new XMLHttpRequest();
  xhr.open("GET", "logout.php", false);
  xhr.send();
});
</script>