<?php

$log_file = 'attendance.log';

// Создание файла лога, если он не существует
if (!file_exists($log_file)) {
    file_put_contents($log_file, "Дата,Время,Пользователь\n");
}

// Определение пользователя
if (empty($_SESSION['aid'])) {
    $_SESSION['aid'] = -1;
    $user = "Гость";
} else {
    $user = "Пользователь" . $_SESSION['aid'];
}

// Запись данных в файл лога
$log_entry = date('Y-m-d') . "," . date('H:i:s') . "," . $user . "\n";
file_put_contents($log_file, $log_entry, FILE_APPEND);
?>
